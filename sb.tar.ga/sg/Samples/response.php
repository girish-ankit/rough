<?php

error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', 1);


require_once "../SurveyGizmoAutoLoader.php";

//set token & secret (From .credentials file, copy .credentials.example to .credentials and supply your API authentication credentials accordingly)
$credentials = parse_ini_file('config.credentials');

try {
  \SurveyGizmo\SurveyGizmoAPI::auth($credentials['SG_API_KEY'], $credentials['SG_API_SECRET']);
} catch (\SurveyGizmo\Helpers\SurveyGizmoException $e) {
  testLog("Error Authenticating", $e);
  die;
}

\SurveyGizmo\ApiRequest::setRepeatRateLimitedRequest(10);
if (1 == 12) {
  $survey_id = 4329738;
} else {
  $survey_id = 4512903;
}

$survey = \SurveyGizmo\Resources\Survey::get($survey_id);
//print_r($survey); die();
$responses = $survey->getResponses();
$answer_count = count($responses->data);
//echo $answer_count; die();
//print_r($responses->data); die();

$response_id = reset($responses->data)->id;
//echo $response_id; die();

$response = $survey->getResponse($response_id);
//print_r($response); die();

$j=0;
$answer = 'Ankit';

foreach ($response->survey_data as $key => $value) {
 // print_r($value); die();
  
  $id = $value['id'];

  $response->survey_data[$id]['answer'] = $answer.' --- '.$j;
  $j++;
}

$response->status = 'Complete';
$ret = $response->save();

echo $ret; die();

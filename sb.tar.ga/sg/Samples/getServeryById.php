<?php

error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', 1);


require_once "../SurveyGizmoAutoLoader.php";

//set token & secret (From .credentials file, copy .credentials.example to .credentials and supply your API authentication credentials accordingly)
$credentials = parse_ini_file('config.credentials');

try {
    \SurveyGizmo\SurveyGizmoAPI::auth($credentials['SG_API_KEY'], $credentials['SG_API_SECRET']);
} catch (\SurveyGizmo\Helpers\SurveyGizmoException $e) {
    testLog("Error Authenticating", $e);
    die;
}

\SurveyGizmo\ApiRequest::setRepeatRateLimitedRequest(10);


if ($_GET['q']) {
    $survey_id = $_GET['q'];
} else {
    echo 'wrong request'; die();
}
$data = '';
$survey = \SurveyGizmo\Resources\Survey::get($survey_id);
//echo '<pre>';
//print_r($survey); die();
$id = $survey->id;
$title = $survey->title;
$internal_title = $survey->internal_title;
$links = $survey->links->campaign;
$created_on = strtotime($survey->created_on);

$data .= '<h1>' . $title . '</h1>';
$data .= '<p><b>Created On: </b>'. date('d/m/Y H:i:s', $created_on).'</p>';
print_r($survey->pages[0]->questions);

$i=1;
$output = '';

foreach ($survey->pages[0]->questions as $key => $value) {
  //  echo '*************';
  // echo '<pre>';
  // print_r($value);
    $question_id = $value->id;
    $question_title = $value->title->English;
    $question_type = $value->type;
    $is_required ='';
    if($value->properties->required){
      $is_required = '*';  
    }
    

    $options = array();

    $output .= '<br /><br /><b> Question:'.$i .$is_required.': '.  $question_title . '</b><br />';
    
    

   if($question_type == 'TEXTBOX'){
        $output .= '<input type="' . $question_type . '" name="" value="" /><br>';
       
   }else{
       foreach ($value->options as $key_in => $value_in) {
      //  $options[$value_in->id] = $value_in->value;
        $output .= '<input type="' . $question_type . '" name="" value="' . $value_in->id . '" />' . $value_in->value . '<br>';
    }
       
   }
    
    $i++;
}

$data .= $output;
 $data .= '<br />';
$data .= '<input type="hidden" name="" value="'.$links.'" />';
$data .= '<input type="submit" />';
echo $data;

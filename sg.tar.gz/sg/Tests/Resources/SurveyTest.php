<?php
namespace SurveyGizmo\Tests;

class SurveyTest extends TestCase
{
    public function testIsTrue()
    {
        $this->assertSame(1, 1);
    }
}
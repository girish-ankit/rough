<?php
namespace SurveyGizmo\Tests;
require_once(__DIR__ . '/../SurveyGizmoAutoLoader.php');
/**
 * test cases base class
 */
class TestCase extends \PHPUnit_Framework_TestCase
{

}
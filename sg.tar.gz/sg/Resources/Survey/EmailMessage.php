<?php
namespace SurveyGizmo\Resources\Survey;

use SurveyGizmo\ApiResource;
use SurveyGizmo\Helpers\SurveyGizmoException;

/**
 * Class for EmailMessage API objects
 * EmailMessages are a sub-object of Campaigns
 */
class EmailMessage extends ApiResource
{
	/**
	 * API call path
	 */
	static $path = "/survey/{survey_id}/surveycampaign/{campaign_id}/emailmessage/{id}";

	/**
	 * Fetch list of SurveyGizmo EmailMessage Objects
	 * @access public
	 * @param int $survey_id - Survey ID
	 * @param int $campaign_id - parent Survey Campaign ID
	 * @param SurveyGizmo\Filter $filter - filter object
	 * @param Array $options
	 * @return SurveyGizmo\ApiResponse Object with SurveyGizmo\EmailMessage Objects
	 */
	public static function fetch($survey_id = null, $campaign_id = null, $filter = null, $options = null) {
		if ($campaign_id < 1 && $survey_id < 1) {
			throw new SurveyGizmoException("Missing campaign or survey ID", 500);
		}
		$response = self::_fetch(array('id' => '', 'survey_id' => $survey_id, 'campaign_id' => $campaign_id,), $filter, $options);
		return $response;
	}

	/**
	 * Get Campaign Obj by survey id, campaign id and email message id
	 * @access public
	 * @param int $survey_id - survey id
	 * @param int $campaign_id - campaign id
	 * @param int $id - email id
	 * @return SurveyGizmo\EmailMessage Object
	 */
	public static function get($survey_id = null, $campaign_id = null, $id = null){
		if ($id < 1 && $survey_id < 1 && $campaign_id < 1) {
			throw new SurveyGizmoException("IDs required", 500);
		}
		return self::_get(array(
			'campaign_id' => $campaign_id,
			'survey_id' => $survey_id,
			'id' => $id,
		));
	}

	/**
	 * Save current EmailMessage Obj
	 * @access public
	 * @return SurveyGizmo\ApiResponse Object with SurveyGizmo\EmailMessage Object
	 */
	public function save()
	{
		return $this->_save(array(
			'campaign_id' => $this->campaign_id,
			'survey_id' => $this->survey_id,
			'id' => $this->exists() ? $this->id : ''
		));
	}

	/**
	 * Delete current EmailMessage Obj
	 * @access public
	 * @return SurveyGizmo\ApiResponse Object
	 */
	public function delete(){
		return self::_delete(array(
			'campaign_id' => $this->campaign_id,
			'survey_id' => $this->survey_id,
			'id' => $this->id,
		));
	}
}

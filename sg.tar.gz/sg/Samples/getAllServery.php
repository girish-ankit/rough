<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', 1);
ini_set('memory_limit', '512M'); 

function testLog($message, $dump = null)
{
	echo "<h3>" . $message . "</h3>";

	if ($dump) {
		testVardump($dump);
	}
}

function testVardump($dump)
{
	echo "<pre>";
	var_dump($dump);
	echo "</pre>";
}

testLog("TESTING Library");
//Require autoloader
require_once "../SurveyGizmoAutoLoader.php";

//set token & secret (From .credentials file, copy .credentials.example to .credentials and supply your API authentication credentials accordingly)
$credentials = parse_ini_file('config.credentials');

//authenticate
testLog("Authenticating");

try {
	\SurveyGizmo\SurveyGizmoAPI::auth($credentials['SG_API_KEY'], $credentials['SG_API_SECRET']);
} catch (\SurveyGizmo\Helpers\SurveyGizmoException $e) {
	testLog("Error Authenticating", $e);
	die;
}

\SurveyGizmo\ApiRequest::setRepeatRateLimitedRequest(10);




$filter = new \SurveyGizmo\Helpers\Filter();
/*
$filter_item = new \SurveyGizmo\Helpers\FilterItem();
$filter_item->setField('title');
$filter_item->setOperator('!=');
$filter_item->setCondition('TEST from API');
$filter->addFilterItem($filter_item);
 */

//$surveys = \SurveyGizmo\Resources\Survey::fetch($filter,$options);


if($_GET['page']){
   $page = $_GET['page']; 
}else{
 $page = 1;   
}

$results_per_page = 5;

$path = 'http://localhost/rough/sg/Samples/getAllServery.php?page=';




$options = array('page' => $page, 'limit' => $results_per_page);
$surveys = \SurveyGizmo\Resources\Survey::fetch($filter, $options);

$total_count = $surveys->total_count;
$total_pages = $surveys->total_pages;

$output = '<ul>';
for($i=1; $i < $total_pages; $i++){
    $output .= '<li><a href="'.$path.$i.'">'.$i.'</a></li>';
    
}
$output .= '</ul>';

echo $output;

$data = '';
$detial_path= 'http://localhost/sg/Samples/getServeryById.php?q=';
//print_r($surveys->data);

for($j=0; $j < $results_per_page; $j++){
   $data .= '<p><a href="'.$detial_path.$surveys->data[$j]->id.'">'.$surveys->data[$j]->title.'</a></p>'; 
}

echo $data;